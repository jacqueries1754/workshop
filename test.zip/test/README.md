
2. cd test
3. chmod 755 installexam.sh
4. ./installexam.sh lb-exam-1.0.deb
5. take-exam.sh
